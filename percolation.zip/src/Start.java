import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;
import edu.princeton.cs.algs4.StdIn;

public class Start {
    public static void main (String [] args) {
        int n = StdIn.readInt();
        System.out.println(n);
    }
}